import sys
print(f"Python version: {sys.version}")
print(f"Python path: {sys.executable}") 